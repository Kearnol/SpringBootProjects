package com.dk.hopper.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PurchaseController {
    
	@RequestMapping("/")
    public String index(Model model) {
        
        String name = "Devin Kearns";
        String itemName = "Xbox Series X";
        double price = 400.00;
        String description = "For crispy halo clips";
        String vendor = "Microsoft";
    
    	model.addAttribute("name", name);
    	model.addAttribute("itemName", itemName);
    	model.addAttribute("price", price);
    	model.addAttribute("description", description);
    	model.addAttribute("vendor", vendor);
    
        return "index.jsp";
    }
    //...
    

}
